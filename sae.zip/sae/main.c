#include "colors.h"

#define PIXEL_SIZE 50
#define SIZE_MAT 270054
#define PIMAGE "Pas d'image"



int main(int argc,char *argv[])
{
    char source[FILENAME_MAX]; /* FILENAME_MAX est d�fini dans stdio.h */
    char nomf1[255];
    char source1[FILENAME_MAX];
    FILE * image1;

    char nomf2[255];
    char source2[FILENAME_MAX];
    FILE * image2;


    int choixMenu;



    if (argc == 1){
        printf("Entrer le chemin vers le repertoire de travail.\n");
        printf("Source: \n");
        gets(source);


        printf("\n---Menu---\n\n");
        printf("1.Passage en niveau de gris\n");
        printf("2.Inversion des couleurs\n");
        printf("3.Image monochrome\n");
        printf("4.Extraction de contours\n");
        printf("5.Superposition d'image");
        printf("\nVotre choix?\n\n");
        scanf("%d",&choixMenu);

        printf("Entrer le nom du fichier:\n");
        scanf("%s",nomf1);

        strcpy(source1, source);
        strcpy(sourceWrite, source);
        strcat(sourceWrite, "\\result.bmp");
        strcpy(source2, source);
        strcat(source1, "\\");
        strcat(source2, "\\");
        strcat(source1, nomf1);

        if(choixMenu == 5){
            printf("\nEntrer le nom du deuxieme fichier:\n");
            scanf("%s",nomf2);
            strcat(source2, nomf2);
            image2 = fopen(source2, "rb");
            if (image2 == NULL){
                perror(source2);
            }

    }

        image1 = fopen(source1, "rb");
        if (image1 == NULL)
            perror(source1);
        else
        {

                affichageMenu(choixMenu,image1,image2);

                printf("\n---Resultat termine---\n");}
                printf("\nMerci d'avoir utilise ce programme. A bientot !\n");

    } else {

        strcpy(source, argv[1]);
        choixMenu = (*argv[2]) - 48;
        strcpy(nomf1, argv[3]);
        strcpy(source1, source);
        strcat(source1, "\\");
        strcat(source1, nomf1);
        strcpy(sourceWrite, source);
        strcat(sourceWrite, "\\result.bmp");

        if(choixMenu == 5){
            strcpy(source2, source);
            strcat(source2, "\\");
            strcpy(nomf2, argv[4]);
            strcat(source2, nomf2);
            image2 = fopen(source2, "rb");
            if (image2 == NULL){
                perror(source2);
            }
        }

        image1 = fopen(source1, "rb");
        if (image1 == NULL)
            perror(source1);
        else
        {

                affichageMenu(choixMenu,image1,image2);

}


    }

    fclose(image1);

    if(choixMenu == 5){
        fclose(image2);
    }



    return 0;
}




