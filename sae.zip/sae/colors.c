#include "colors.h"

//-------------------------------//
//-                             -//
//-      Fonctions sur les      -//
//-     diff�rentes couleurs    -//
//-                             -//
//-                             -//
//-------------------------------//

//Pour les fonctions suivantes:
//pixel[0] est pour le rouge
//pixel[1] est pour le vert
//pixel[2] est pour le bleu


//IMAGE EN GRIS
void gris (FILE * fichier1){

    FILE * resultat = fopen(sourceWrite, "wb");

    //Lecture du fichier1 pour le refaire modifi� sur result
    unsigned char header[HEADER];
    fread(header, sizeof(unsigned char), HEADER, fichier1);
    fwrite(header, sizeof(unsigned char), HEADER, resultat);

    //initialisation de la longueur et hauteur
    int L = *(int*)&header[18];
    int H = abs(*(int*)&header[22]);

    unsigned char pixel[3];//Creation des couleurs
    for (int y = 0 ; y < H ; ++y) {
        for (int x = 0 ; x < L ; ++x) {
            fread(pixel, 3, 1, fichier1); // On lit le pixel d'origine
            unsigned char gris = pixel[0] * 0.3 + pixel[1] * 0.58 + pixel[2] * 0.11; // On definit le gris
            memset(pixel, gris, sizeof(pixel)); // On alloue la zone m�moire
            fwrite(&pixel, 3, 1, resultat); // On �crit le pixel modifi�
        }
    }

    fclose(resultat);
}

//IMAGE AVEC LES COLEURS EN NEGATIVE
void negative (FILE * fichier1){

    FILE * resultat = fopen(sourceWrite, "wb");

    //Lecture du fichier1 pour le refaire modifi� sur result
    unsigned char header[HEADER];
    fread(header, sizeof(unsigned char), HEADER, fichier1);
    fwrite(header, sizeof(unsigned char), HEADER, resultat);

    //initialisation de la longueur et hauteur
    int L = *(int*)&header[18];
    int H = abs(*(int*)&header[22]);

    unsigned char pixel[3];//Creation des couleurs
    //Repetion avec une boucle pixel par pixel
    for (int y = 0 ; y < H ; ++y) {
        for (int x = 0 ; x < L ; ++x) {
            fread(pixel, 3, 1, fichier1); // On lit le pixel d'origine
           //Inversion des coleurs des pixels
            pixel[0]=-pixel[0];
            pixel[1]=-pixel[1];
            pixel[2]=-pixel[2];

            fwrite(&pixel, 3, 1, resultat); // On �crit le pixel modifi�
        }
    }
    fclose(resultat);
}

//IMAGE MONOCHROME (NOIR ET BLANC)
void monochrome (FILE * fichier1){

    FILE * resultat = fopen(sourceWrite, "wb");

    //Lecture du fichier1 pour le refaire modifi� sur result
    unsigned char header[HEADER];
    fread(header, sizeof(unsigned char), HEADER, fichier1);
    fwrite(header, sizeof(unsigned char), HEADER, resultat);

    //initialisation de la longueur et hauteur
    int L = *(int*)&header[18];
    int H = abs(*(int*)&header[22]);

    unsigned char pixel[3];//Creation des couleurs
    //Repetion avec une boucle pixel par pixel
            for (int y = 0 ; y < H ; ++y) {
                for (int x = 0 ; x < L ; ++x) {
                    fread(pixel, 3, 1, fichier1); // On lit le pixel d'origine
                    pixel[0]=pixel[1]=pixel[2];
                    unsigned char monochrome = pixel[0] * 0.3 + pixel[1] * 0.58 + pixel[2] * 0.11; // On definit le gris
                    memset(pixel, monochrome, sizeof(pixel)); // On alloue la zone m�moire
                    //On met defini le noir et le blanc
                    if (pixel[0]<127){
                        pixel[0]=0;
                    }else if (pixel[0]>127){
                        pixel[0]=255;
                    }

                    if (pixel[1]<127){
                        pixel[1]=0;
                    }else if (pixel[0]>127){
                        pixel[1]=255;
                    }

                    if (pixel[2]<127){
                        pixel[2]=0;
                    }else if (pixel[0]>127){
                        pixel[2]=255;
                    }

                    fwrite(&pixel, 3, 1, resultat);// On �crit le pixel modifi�
        }
    }
    fclose(resultat);
}

//IMAGES AVEC SURPERPOSITION
void superposition (FILE * fichier1, FILE * fichier2){

    if(fichier2 == NULL){
        printf("Impossible, un seul fichier est charg�");
    }else{

        FILE * resultat = fopen(sourceWrite, "wb");

        //Lecture du fichier1 et fichier2 pour le refaire modifi� sur result
        unsigned char header[HEADER];
        fread(header, sizeof(unsigned char), HEADER, fichier1);
        fread(header, sizeof(unsigned char), HEADER, fichier2);
        fwrite(header, sizeof(unsigned char), HEADER, resultat);

        //initialisation de la longueur et hauteur
        int L = *(int*)&header[18];
        int H = abs(*(int*)&header[22]);

        unsigned char pixel[3];//Creation des couleurs
        unsigned char pixel_2[3];
        //Repetion avec une boucle pixel par pixel
        for (int y = 0 ; y < H ; ++y) {
            for (int x = 0 ; x < L ; ++x) {
                fread(pixel, 3, 1, fichier1); // On lit le pixel d'origine
                fread(pixel_2, 3, 1, fichier2);

                //On fusionnent les images puis on divise par 2 pour plus de nettete
                pixel[0] = (pixel[0]+pixel_2[0])/2;
                pixel[1] = (pixel[1]+pixel_2[1])/2;
                pixel[2] = (pixel[2]+pixel_2[2])/2;

                fwrite(&pixel, 3, 1, resultat); // On �crit le pixel modifi�
            }
        }
        fclose(resultat);
    }


}

//IMAGES AVEC CONTOURS
void contour (FILE * fichier1){

    FILE * resultat = fopen(sourceWrite, "wb");

    unsigned char header[HEADER];
    fread(header, sizeof(unsigned char), HEADER, fichier1);
    fwrite(header, sizeof(unsigned char), HEADER, resultat);

    //initialisation de la longueur et hauteur
    int L = *(int*)&header[18];
    int H = abs(*(int*)&header[22]);

    unsigned char pixel[3];//Image en gris clair
    for (int y = 0 ; y < H ; ++y) {
        for (int x = 0 ; x < L ; ++x) {
            fread(pixel, 3, 1, fichier1); // On lit le pixel d'origine
            unsigned char gris = pixel[0] * 0.3 + pixel[1] * 0.58 + pixel[2] * 0.11; // On definit le gris
            memset(pixel, gris, sizeof(pixel)); // On alloue la zone m�moire



            fwrite(&pixel, 3, 1, resultat); // On �crit le pixel modifi�

        }
    }
    fclose(resultat);
}


int affichageMenu(int choixMenu, FILE * fichier1, FILE * fichier2){

    switch (choixMenu){
    case 1 :
        gris (fichier1);
        break;
    case 2 :
        negative (fichier1);
        break;
    case 3 :
        monochrome (fichier1);
        break;
    case 4 :
        contour (fichier1);
        break;
    case 5 :
        superposition (fichier1,fichier2);
        break;
    default:
        printf("\nErreur, cette couleur n'existe pas\n");
    }
    return choixMenu;
}
