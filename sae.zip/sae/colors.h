#ifndef COLORS_H
#define COLORS_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define HEADER 54

char * sourceWrite[255];

int affichageMenu(int choixMenu, FILE * fichier1, FILE * fichier2);

void gris(FILE * fichier1);
void contour (FILE * fichier1);
void negative(FILE * fichier1);
void monochrome(FILE * fichier1);
void superposition(FILE * fichier1, FILE * fichier2);

#endif // COLORS_H
